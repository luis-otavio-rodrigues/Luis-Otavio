<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atividade 2</title>
    <style>
        body {
                background-color: rgb(255, 241, 241);
                margin-top: 100px;
                text-align: center;
              
        }
        .oie{
            border-radius: 19px;
            padding: 10px 10px;
            background-color: rgba(247, 144, 144, 1);
            margin-left: 35%;
                        margin-right: 35%;
        }
    </style>
</head>
<body>
    <?php 

$nome = $_POST['nome'];
$senha = $_POST['senha'];

if($nome == "Luis" and $senha == 1234 ){
    echo "<div class='oie'><h1>Bem vindo gerente de vendas $nome</h1></div>";
}
else{
    echo"<div class='oiee'><h1>Senha ou nome de usuario incorretos</h1></div>";
}
?>
</body>
</html>

