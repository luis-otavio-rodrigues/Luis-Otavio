<?php
$n = $_POST['nome'];
$e = $_POST['endereco'];
$s = $_POST['sx'];
$i = $_POST['idade'];
echo "Meu nome é $n<br>";
if($i >= 18){
    echo "tenho $i anos<br>";
    echo "Moro no endereço $e<br>";
    echo "Sou do sexo $s<br>";
}
else{
    echo "Menor de idade";
}
?>